# Ebuild hello world
playing around with gentoo
